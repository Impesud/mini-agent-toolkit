# Mini Agent Toolkit (Python)

Mini progetto didattico che implementa un **“mini agente” basato su tool**: dato un prompt testuale, l’agente riconosce alcune intenzioni (rule-based) e invoca il tool corrispondente tramite un **registro (ToolRegistry)**. Ogni esecuzione viene tracciata su file di log.

## Funzionalità

- **Tool Registry** per registrare tool (funzioni) con nome e descrizione.
- **Routing dell’agente** (regole semplici su keyword) verso i tool disponibili.
- Tool inclusi:
  - `add` → somma 2 numeri
  - `count` → conta le parole in una stringa
  - `upper` → converte una stringa in maiuscolo
  - `reverse` → inverte i caratteri di una stringa
- **Logging** delle azioni in `agent_activity.log`.
- **Test automatici** con `pytest`.

## Struttura del progetto

```
mini_agent/
├─ app/
│  ├─ agent.py        # logica dell’agente (routing)
│  ├─ tools.py        # tool disponibili
│  ├─ registry.py     # registro tool
│  └─ logger.py       # logging su file
├─ tests/
│  └─ test_agent.py   # unit test
├─ main.py            # demo eseguibile
├─ requirements.txt
└─ agent_activity.log # generato/aggiornato a runtime
```

## Requisiti

- Python **3.9+** (consigliato 3.10+)
- Pip

## Installazione

1) Clona o copia la cartella del progetto.

2) (Consigliato) Crea e attiva un virtual environment:

```bash
python -m venv .venv
# Linux/Mac
source .venv/bin/activate
# Windows
.venv\\Scripts\\activate
```

3) Installa le dipendenze:

```bash
pip install -r requirements.txt
```

> Nota: in `requirements.txt` sono presenti anche `openai` e `python-dotenv`. In questa versione del progetto non sono strettamente necessari per l’esecuzione della demo (non c’è una chiamata a LLM), ma possono essere utili se estendi l’agente.

## Configurazione (.env)

Nel repository è presente un file `.env`. **Non committare mai chiavi o segreti**.

- Se devi usare variabili d’ambiente, crea un file `.env` locale (non versionato) e caricalo a runtime con `python-dotenv`.
- Se nel progetto è stata committata una chiave, **ruotala/revocala immediatamente** e rimuovila dalla history.

## Come eseguire

Esegui la demo:

```bash
python main.py
```

Al termine troverai le azioni registrate in `agent_activity.log`.

## Esempi (input/output)

Esempi tipici (prompt → risposta):

1) Somma due numeri

**Input**

```
Somma questi numeri: 15.5 e 10
```

**Output**

```
Risultato (add): 25.5
```

2) Conta parole

**Input**

```
Conta queste parole: l'agente funziona bene
```

**Output**

```
Risultato (count): 6
```

3) Inverti testo

**Input**

```
Inverti il senso di questa stringa
```

**Output**

```
Risultato (reverse): agnirts atseuq id osnes li itrevnI
```

4) Fallback (nessun tool)

**Input**

```
Ciao, come stai?
```

**Output**

```
Nessun tool attivato.
```

> Importante: nella versione corrente il trigger per il tool `upper` è la keyword **“grida”** (vedi `app/agent.py`). Un prompt che contiene “urla” non attiva il tool.

## Eseguire i test

```bash
pytest -q
```

## Parte teorica

### 1) Pattern “Agent + Tools” (tool calling)

Un agente “tool-based” separa:

- **Decisione (routing)**: capire *quale* azione eseguire (qui con semplici regole su keyword).
- **Esecuzione (tool)**: funzioni pure e riutilizzabili (somma, conta parole, ecc.).

Questo pattern è la base di molti sistemi agentici moderni: una componente decide la strategia (anche con un LLM), e una componente esegue operazioni concrete e verificabili.

### 2) Registro dei tool (Tool Registry)

`ToolRegistry` è una mappa `name -> {func, description}` che consente:

- estendere facilmente l’agente aggiungendo nuovi tool;
- disaccoppiare la logica dell’agente dall’implementazione dei tool;
- mantenere un catalogo di capabilities disponibili.

### 3) Logging e osservabilità

Ogni invocazione tool viene registrata (azione, input, output) in `agent_activity.log`. Nella pratica, logging e metriche sono fondamentali per:

- debug di comportamenti inattesi;
- audit delle azioni dell’agente;
- analisi di frequenza tool / errori.

### 4) Testabilità

I tool sono funzioni deterministiche → facili da testare (unit test). Anche il registro è testabile (recupero tool esistente / non esistente). Questo migliora affidabilità e manutenibilità.

## Livello di difficoltà

**Base / Intermedio (Beginner+)**

- Richiede familiarità con Python (funzioni, import, classi semplici).
- Introduce concetti fondamentali di architettura “agentica” in modo accessibile.

## A chi è rivolto

- Studenti o junior dev che vogliono capire il pattern **agent + tools**.
- Chi sta imparando **Python OOP** e strutturazione di un piccolo progetto.
- Chi vuole una base semplice da estendere verso un agente con **LLM** (es. routing con modello + tool registry).

## Come estendere (idee)

- Aggiungere un nuovo tool in `app/tools.py`, registrarlo in `main.py` e gestire il trigger in `app/agent.py`.
- Migliorare il parsing (es. estrarre solo la parte dopo i “:” per `count` e `upper`).
- Gestire sinonimi (es. “urla” → `upper`) o usare un classificatore/LLM per decidere il tool.
- Aggiungere gestione errori e validazione input (numeri mancanti, prompt ambigui, ecc.).

